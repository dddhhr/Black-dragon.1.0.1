import subprocess
import os
import sys
import time
import shutil
a = '\033[31m'      #رمحا
s = '\033[33m'   #رفصا
r = '\033[32m'    #رضخا
k = '\033[90m'     #يدامر
o = '\033[0m'
w = '\033[36m'
g = '\033[34m'
def check_and_install_pagekite():
    # Check if pagekite is installed
    if shutil.which("pagekite") is None:
        print("[!] Pagekite is not installed, installing now...")
        try:
            subprocess.run(["sudo", "apt", "install", "-y", "pagekite"], check=True)
            print("[+] Pagekite has been installed successfully.")
        except subprocess.CalledProcessError:
            print("[X] Error occurred while installing Pagekite.")

# Run the check before executing the rest of the code
check_and_install_pagekite()

# Your main script starts here
print("")
# Add your code below
def slow_print(text, delay=0.1):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()  # لإضافة سطر جديد بعد الطباعة

# مسح الشاشة
os.system('clear')

# النص المطلوب
text = """
Welcome to the legendary ethical hack  tool
Black  Dragon .
With you was the great programmer'\033[36m' Mohamed Lamine'\033[0m'

I do not bear any '\033[31m'responsibility'\033[0m' for any illegal use of my tool. .
"""
# عرض النص أولاً
slow_print(text)
def show_menu():
    os.system('clear' if os.name == 'posix' else 'cls')
    print(f'''
{r}•{k}

{a}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{a}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣴⣶⡿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⣀⣤⣴⣾⣿⣿⡿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡴⢚⢫{a}⣽⣿⣿⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡶⠛⠳⣎{a}⢥⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⡿⠁⠀⠀⠀⣹{a}⢾⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣆{a}⣆⣶⣶⣶⡶⣶⢶⣀⣀⣀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡴⢛⡏⠀⠀⠀⣠⡖⢏{a}⠺⣿⣿⣷⣦⣤⣤⣤⠶⠖⠊{k}⠀⠀⣀⣤⣤⡴⣖⡾⠟⠛⠉⠉⠉⠙⣏{a}⡞⣼⣼⣷⣿⡿⠿⠛⠉⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⣠⠾⣉⠖⡩⢝⡦⠴⣞⠱⡸⢌⣣{a}⣽⣿⣿⠿⠛⠉{k}⣀⣠⣤⣶⡾⠟⠛⠋⠉⠙⣾⣇⠀⠀⠀⢀⣀⣤{a}⣿⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⢀⣴⢋⠖⡱⢊⡕⢪⢔⠫⡔⢫{a}⣱⣾⠿⠛⢉{k}⣠⡴⣶⠿⠟⠋⠁⠀⠀⠀⠀⠀⢀⣠⡿⣹⢳⣻⠻⡽{a}⣹⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⣰⠟⣤⢋⡎⢵⡩⢜⢣⢎⣣{a}⣽⠟⢋{k}⣡⡴⣞⣯⠟⠋⠁⠀⠀⠀⠀⣀⣤⢶⢶⣛⢯⣓⢧⣓⡏⣶⢫{a}⣽⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  {k}✩₊˚.☪︎ ⁺₊✧{a}
{k}⠀⠀⠀⠀⠼⢯⣞⡤⢳⡸⢅⡞⣩⣖⠷⠋⠳⢶⣏⢧⣽⠋⠀⠀⠀⢀⣠⡴⣞⡻⡝⣮⢝⡲⣭⢞⡼⣣⢧⣛⢶⣫{a}⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{k} programmer :{w} mohammed{a}-{w}lamin{a}⠀
{k}⠀⠀⠀⠀⠀⠀⠈⠻⣵⢊⠷⡸⢥⣧⠀⠀⠀⠀⠉⠳⣾⣦⣠⣤⡞⣯⠳⣝⡲⣭⢳⣣⢏⡷⢳⣎⢷⡹⢮⡝⣮⢳{a}⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⣸⣏⣞⣱⡧⠾⢷⣄⡀⠀⠀⠀⠈⠳⣏⡶⣹⢖⡻⣜⡳⣭⢳⡭⣞⡽⣳⢎⡷⣹⢧⣻⠼⣏{a}⢿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀   {k}Operating system : {a}Kali-Linux{k}/{o}termux{a}
{k}⠀⠀⠀⠀⠀⠀⠀⣤⣿⣩⣥⣶⣿⣭⣶⣿⠿⠛⠛⠀⠀⠙⣷⡹⣎⠷⣭⢳⣭⢳⡝⣮⢳⣝⢾⡹⢧⣟⢮⣟⣭⢿⣮{a}⣝⠻⢿⣧⡀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⣠⡴⣞⡟⣻⣛⢿⡻⣿⣿⣦⣤⣄⡀⠀⠀⠀⢹⡷⣭⣻⢼⡳⣞⡽⣺⡭⣟⢮⣯⢽⣻⡼⣏⡾⣞⡽⣞⡿⣿{a}⣦⣈⠉⠀⠀⠀⠀⠀{k}⠀tool : Black-dragon  ⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⣰⠿⣭⣷⣭⡞⣵⡹⣎⠷⣭⣛⣿⣿⣭⣉⠀⠀⠀⠀⢿⣧⣛⣮⢷⣫⣞⠷⣽⢞⣯⠾⣽⢶⣻⣭⢷⡯⣟⣳⣟⡿⣿{a}⣿⣷⣤⡀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⢀⣹⡿⣯{a}•{k}⣴⢿⡹⢶⡹⣎⡟⣶⡹⣖⢿⣿⡿⠛⠦⠀⠀⢸⡷⣏⣾⡳⣽⡺⣟⡽⣾⣭⢿⡽⣞⣷⣫⣟⡾⣽⣳⣯⣿⣿⡿⠿⠛⠛⠲⠀⠀{k}⠀⠀Instagram:{w} dddhhr{a}_
{k}⣾⣤⡶⣿⡹⣞⡵⣫⣞⣽⣣⣟⣵⣻⠷⣟⡾⣭⢿⣿⣦⡀⠀⠀⢸⡿⣽⢶⣻⣳⢿⣹⡽⣶⢯⣟⡾⣿⡷⣟⣾⣽⣳{a}⣿⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠻⣷⣝⡶⠟⣳⡿⠋⠉⠀⠈⠉⠛⡿⣸⢻⣽⡞⣯⣿⡿⣷⠀⠀⣿⢿⡽⣞⡷⣯⣟⣷⣻⣽⣻⢾⣽⣻⢿⣜{a}⢿⣾⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠘⠻⣤⣾⡟⠀⠀⠀⠀⠀⠀⣀⣴⣿⢸⣿⣽⡳⣿⣷⡌⠁⣰⣿⢯⡿⣽⣻⣵⣻⣞⡷⣯⣟⡿⣾⣽⣻⢿⣦{a}⠙⢿⣿⠀⠀⠀⠀⠀  ⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠉⠉⠀⠀⠀⢀⣰⣾⣿⣿⢇⣿⡿⣶⢿⡿⠉⢷⢀⣿⣏⣿⣹⢷⡿⣾⢷⣏⣿⢿⣾⣿⣷⣿⣿⣿⣿⣷{a}⠾⢿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⡿⣣⣿⢿⡽⣯⢿⡇⠀⣠⣿⣟⣾⣳⣯⢿⣽⢯⣟⣯⣿⡟{a}⣿⣿⣿⣿⠿⠿⠿⣿⣷{a}⣅⠓⠀⠀⠀⠀⠀⠀⠀⠀    ╭╮╱╱╱╱╱╱╱╭╮╱╱╭╮
{k}⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⡿⣫⣾⢿⡽⣯⢿⡽⣿⣠⣼⣿⣻⢾⣳⣯⣿⣟⣾⣟⣯⣿⣽⣷{a}⢻⡿⠋⠀⠀⠀⠀⠀⠉⠙⢷⠀⠀⠀⠀⠀  ⠀⠀   ┃╰┳╮╭━╮╭━┫┣╮╭╯┣┳┳━╮╭━┳━┳━┳╮
{k}⠀⠀⠀⣰⣿⣿⣿⣿⡿⣫⣾⡿⣯⢿⡽⣯⢿⣽⣿⣿⣻⢷⣻⣟⣯⣿⢻⣿⣷⣻⣟⣾⣿⣿⠸⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ┃╋┃╰┫╋╰┫━┫━┫┃╋┃╭┫╋╰┫╋┃╋┃┃┃┃
{k}⠀⠀⢰⣿⣿⣿⣿⢏⣾⣿⢯⣿⡽⣯⣿⣻⣟⣾⣽⣾⣻⣟⣯⣿⣽⡟{a}⢸⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ╰━┻━┻━━┻━┻┻╯╰━┻╯╰━━╋╮┣━┻┻━╯
{k}⠀⠀⢸⣿⣿⣿⣏⣾⣿⡽⣟⣾⢿⣽⡾⣷⡿⣻⣿⣿⣿⣿⣿⣿⡟{a}⠁⣿⠟⠋⠉⠉⠙⠻⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                              ╰━╯
{k}⠀⠈⠘⣿⣿⣿⢸⣿⣯⢿⡿⣽⡿⣯⣿⢿⣇⠉⠀⠀⠀⠀{a}⠉⠿⠁⠀⠃⠀⠀⠀⠀⠀⠀⠘⠁⠀⠀⠀⠀⠀  {a}⠀({o}1{a}){w} ➜{o}Malicious{a} ({o} link attack{a} ) {k}
{k}⠀⠀⠀⠹⣿⣿⢼⣿⣟⣿⣟⣿⣽⣿⣽⣿⣿⣿⣶⣶⣴⣤⣤⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                           
{k}⠀⠀⠀⠀⠘⢿⣏⣿⣿⣻⣾⣟⣿⣾⢿⣾⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠀({o}2{a}){w} ➜{o}Extract information from{a}({a} phone's IP{a}){k}⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠙⠪⠿⣿⣯⣿⣟⣿⣿⣟⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠛⠻⠿⠯⠿⠿⠿⠿⠿⠷⠿⠿⢿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a} ⠀⠀⠀({o}3{a}){w}➜{o}Social media{a} guessing {o} ⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣶⣿⣿⣷⣶⣶⡄⠘⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{k}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⠿⠿⠿⠿⣿⡿⢀⣿⣿⣿⣿⡿⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a} ⠀({o}4{a}){w}➜ Download{w} the{a} Emperor{k} theme {k}
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⡿⠁⣼⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀   ⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣷⣶⣤⣤⣤⣶⣿⣿⣿⣿⣿⠟⠁⠸⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a} ⠀⠀({o}5{a}){w}➜ install kali-links {k}
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠁⠀⠀⠀⠈⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠛⠿⠿⠿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a} ⠀  ({o}6{a}){w}➜ {o}....... {o}
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠀⠀⠀⣦⡄{k}⢹⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠀⠀⠈⣿{k}⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a} ⠀  ({o}0{a}){w}➜ {o}({a}exit{o}){k}⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠀⠀⠀⠀⢸{k}⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠀⠀⠀⠀⣼{k}⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

''')
    print(" ")
    print("")
    print("")
def run_script5():
    print(f''' {k} Loading {a}......''')
    subprocess.run(["python3", "data/bin/install.py"])

def run_script1():
    print(f''' {k} Loading {a}......''')
    subprocess.run(["python3", "data/bin/sos.py"])  # This will actually run the script
def run_script4():
    print(f''' {k} Loading {a}......''')
    subprocess.run(["python3", "data/bin/Kali-Luxax.py"])

def run_script2():
    print(f''' {k} Loading {a}......''')
    subprocess.run(["python3", "data/bin/3script.py"])  # Replace with actual script path

def run_script3():
    print(f''' {k} Loading {a}......''')
    subprocess.run(["python3", "data/bin/guess.py"])  # Replace with actual script path
def run_script6():
    print(f''' {k} Loading {a}......''')
    subprocess.run(["python3", "data/bin/"])  # Replace with actual script path

def exit_program():
    print("Exiting the program.")
    exit()

# Main program loop
while True:
    try:
        show_menu()
        choice = input(f"{r}[*]{o}Choose an {o}({a}option{o}){o}:{w} ")

        if choice == "1":
            run_script1()
        elif choice == "2":
            run_script2()
        elif choice == "3":
            run_script3()
        elif choice == "4":
            run_script4()
        elif choice == "5":
            run_script5()
        elif choice == "6":
            run_script6()
        elif choice == "0":
            exit_program()
        else:
            print(f"{s}Invalid choice. Please try again.")
    except KeyboardInterrupt:
        print("\n Le script a été arrêté par l('utilisateur)")
        sys.exit(0)  # إنهاء السكريبت بأمان
