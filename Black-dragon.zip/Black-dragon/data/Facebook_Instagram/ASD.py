import sys
import time
import os
a = '\033[31m'      #رمحا
s = '\033[33m'   #رفصا
r = '\033[32m'    #رضخا
k = '\033[90m'     #يدامر
o = '\033[0m'
w = '\033[36m'
g = '\033[34m'

def slow_print(text, delay=0.1):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()  # لإضافة سطر جديد بعد الطباعة                                                      
# مسح الشاشة
os.system('clear')

# النص المطلوب
text = """
'\033[31m'Sorry you have been blocked by Instagram⚠️ 
"""

# استدعاء الدالة لطباعة النص ببطء
slow_print(text)

print(f'''

{k}

⠀⠀⠀⣠⣶⣶⣿⣶⣦⡀⠀⠀⠀⠀⠀⠀⣠⣶⣿⣷⣶⣦⡀⠀⠀
⠀⠀⣾⡿⣫⣶⣶⣮⡻⣿⡆⠀⠀⠀⢀⣾⣿⢫⣶⣶⣯⡻⣯⡆⠀
⠀⢸⣿⢷⣿⣿⣿⣿⣧⢿⣿⠀⠀⠀⢸⣿⣷⣿⣿⣿⣿⣧⢻⣼⠀
⠀⢸⣿⢸⣿⣿⣿⣿⣿⢸⣿⠀⠀⠀⢸⣿⢻⣿⣿⣿⣿⣿⢸⣿⠀
⠀⢸⣿⢸⣿⣿⠿⣛⣥⣾⣿⣿⣿⣿⣿⣷⣶⣝⡛⢿⣿⣿⢺⢹⠀
⠀⠈⣿⢏⣫⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣅⡾⡜⠀
⠀⢀⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⢇⠀
⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣂
⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷
⣿⡿⠟⠋⠉⠉⠛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠉⠉⠉⠛⠿⣿
⡏⢠⡇⠀ ⠀{a}•{k}⠀⣨⢻⣿⣿⣿⣿⣿⣿⢋⡀{a} •{k}⠀⠀⠀⡆⢸
⠁⣦⡻⢀⠀⠀⠀⡠⢊⣼⣿⣿⣿⣿⣿⣿⡈⠳⠄⠀⠀⠀⠴⣣⡼
⠈⣿⣿⣷⡶⣺⣷⣶⣿⣿⣿⣿⣛⣻⣿⣿⣿⣶⣶⣷⡲⣶⣿⠟⡝
⠀⠈⠫⣭⣾⣿⣿⣿⣿⣿⣿⠟⣩⡙⢿⣿⣿⣿⣿⣿⣿⡾⡣⠊⠀
⠀⠀⠀⠀⠙⠻⢿⣿⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⡟⠋⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣴⣾⣩⣝⣛⢣⣞⣛⣻⣛⡩⢽⣤⣀⠀⠀⠀⠀⠀
=========×××××=============
{o}
Try using a vpn to avoid the ban and run another tool 
Or contact the{ a} programmer{o}: 
 Instagram :{w} @dddhhr_{o}
  Facebook :{w}https://www.facebook.com/dddhhhr
''')
