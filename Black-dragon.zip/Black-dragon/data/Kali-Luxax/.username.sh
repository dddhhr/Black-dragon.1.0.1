#!/bin/bash

# Colors
GRAY="\e[90m"
RED="\e[31m"
RESET="\e[0m"

# Function to check if Tor is running
check_tor() {
    if pgrep -x "tor" > /dev/null; then
        echo -e "${GRAY}Successfully started ${RED}Tor${RESET}"
        echo -e "${GRAY}To verify, type: proxychains curl -s https://check.torproject.org${RESET}"
        echo -e "${GRAY}|${RESET}"
    else
        echo -e "${GRAY}Failed to start ${RED}Tor${RESET}"
        echo -e "${GRAY}Please check manually.${RESET}"
        exit 1
    fi
}

# Ensure Tor is installed
if ! command -v tor &> /dev/null; then
    echo -e "${GRAY}Tor is not installed.${RESET}"
    echo -e "${GRAY}Installing now...${RESET}"
    sudo apt update && sudo apt install tor -y || { echo -e "${GRAY}Error occurred. Please check manually.${RESET}"; exit 1; }
fi

# Start Tor in background if not running
if ! pgrep -x "tor" > /dev/null; then
    nohup tor &> /dev/null 2>&1 &
    disown
    sleep 5
fi

# Check if Tor started successfully
check_tor

# Run the script in the background and detach from the terminal
nohup bash -c "
while true; do
    if ! pgrep -x 'tor' > /dev/null; then
        echo -e '${GRAY}${RED}Tor${GRAY} has stopped! Restarting...${RESET}'
        nohup tor &> /dev/null 2>&1 &
        disown
        sleep 5
        check_tor
    fi
    sleep 1  # Check every second
done
" &> /dev/null 2>&1 & disown
exec zsh
