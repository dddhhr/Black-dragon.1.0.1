sudo apt install chromium -y

pip install 'selenium'
